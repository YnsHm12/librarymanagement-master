
$(function(){
    $('#header').load('structure_page/header.html');
  });