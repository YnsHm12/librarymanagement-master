<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="acceuilG.css">
    <title>Bibliothèque FSJ</title>
</head>
<body>
    <div class="wrap">
        <img src="../Images/log.jpg" width="200px" height="200px">

        <h2>Espace gestionnaire</h2>
           <h1> Bibliothèque faculté des sciences El jadida</h1>
           <h1>Université Chouaib Doukkali</h1> 
                <a href="../Login/login.php">
                    Accéder à l'espace
                </a>
    </div>
</body>
</html>