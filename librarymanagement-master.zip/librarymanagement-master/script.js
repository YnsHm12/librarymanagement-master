$(".shw").click(function(){
    $(".hide").fadeToggle(250);
  });

    $('#bell').click(function() {
      $('.notification').fadeToggle(340);
    });

    $('.click').hover(function() {
      $(this).css(("cursor"),("pointer"));
      });

    $('.click').click(function() {
      window.location.href = '../Emprunts/indexEm.php';
    });

    
 
    

